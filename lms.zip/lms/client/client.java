package com.sapient.lms.client;

import com.sapient.lms.model.*;
import com.sapient.lms.service.*;
import java.util.*;  
public class client {
	public static void main(String args[]) {
		
		 employee e1;employee e2;
		 leavedetails l1; leavedetails l2;
		 leavemanager lm;
		l1 =new leavedetails(10);
		l2 =new leavedetails(20);
		e1=new employee(101,"Abc1","dept1", l1);
		e2=new employee(101,"Abc1","dept1", l2);
	  Scanner in = new Scanner(System.in); 
	
	  
	  	  System.out.println("Enter Employee Id:");
	  	  int employeeId=in.nextInt();
	  	System.out.println("Enter \n1. View leave balance \n" + 
	  			"2 - Apply for leave \n" + 
	  			"3 - Update Leaves  ");
	  	  int operation=in.nextInt();
	  	  switch(operation)
	  	  {
	  	  case 1:if(employeeId==101) 
	  	                  {
	  		             lm =new leavemanager(e1,l1);
	  		            System.out.println("Leaves are: "+lm.viewleaves());
	  	                  }
	  	         else {
	  	        	 lm =new leavemanager(e2,l2);
	  	        	lm.viewleaves();
	  	        	System.out.println("Leaves are: "+lm.viewleaves());
	  	             }
	  		     
	  		     break;
	  	  case 2:if(employeeId==101) 
                     {
	  		 lm =new leavemanager(e1,l1);
	  		
	  		lm.viewleaves();
	        	System.out.println("Leaves are: "+lm.viewleaves());
	        	System.out.println("enter no of leaves you want: ");
	        	int leave=in.nextInt();
	  		try {
				lm.apply(leave);
				lm.viewleaves();
	        	System.out.println("Now Leaves remaining are: "+lm.viewleaves());
			} catch (qexception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	  		
                   }
              else {
            	  lm =new leavemanager(e2,l2);
            
            	  lm.viewleaves();
	  	        	System.out.println("Leaves are: "+lm.viewleaves());
	  	        	System.out.println("enter no of leaves you want: ");
	  	    	  int leave=in.nextInt();
	  	    	  try {
      	  		lm.apply(leave);
      	  	lm.viewleaves();
	        	System.out.println("Now Leaves remaining are: "+lm.viewleaves());
	  	    	  } catch (qexception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	  	    	  
	  	    	  }
	  		     break;
	  	  case 3: if(employeeId==101) 
                 {
	  		 lm =new leavemanager(e1,l1);
	  		 lm.viewleaves();
	        	System.out.println("Leaves are: "+lm.viewleaves());
	        	System.out.println("enter no of leaves you want to set: ");
	  		int leave=in.nextInt();
	  		lm. update(leave);
	  		lm.viewleaves();
        	System.out.println("Now Leaves are: "+lm.viewleaves());
                   }
                 else {
                	 lm =new leavemanager(e2,l2);
                	 lm.viewleaves();
     	        	System.out.println("Leaves are: "+lm.viewleaves());
     	        	System.out.println("enter no of leaves you want to set: ");
     	  		int leave=in.nextInt();
     	  		lm. update(leave);
     	  		lm.viewleaves();
             	System.out.println("Now Leaves are: "+lm.viewleaves());
                   }
	  		     break;
	  	  }
	  	 
	  	
	  	
	  	
	  	         
	}
	         
	     
	         
	                 
	                      
	         

}
