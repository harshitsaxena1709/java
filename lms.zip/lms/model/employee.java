package com.sapient.lms.model;

public class employee {
private int empid;
private String enm;
private String edept;
private leavedetails l;

public employee(int id, String name,String dept,leavedetails l1) {
	this.empid=id; this.enm=name; this.edept=dept;
	 this.l=l1;
	
}



public int getEmpid() {
	return empid;
}

public void setEmpid(int empid) {
	this.empid = empid;
}

public String getEnm() {
	return enm;
}

public void setEnm(String enm) {
	this.enm = enm;
}

public String getEdept() {
	return edept;
}

public void setEdept(String edept) {
	this.edept = edept;
}

}
