package com.sapient.lms.model;

public class leavedetails {

	private int leaves=10;
	
	public leavedetails(int l) {
		this.leaves=l;
	}

	public int getLeaves() {
		return leaves;
	}

	public void setLeaves(int leaves) {
		this.leaves = leaves;
	}
	
}
