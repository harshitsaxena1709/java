package com.sapient.lms.service;

public class qexception extends Exception {

	public qexception(String message) {
		super(message);
	}
}
