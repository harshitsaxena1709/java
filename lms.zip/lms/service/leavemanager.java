package com.sapient.lms.service;

import com.sapient.lms.model.*;

public class leavemanager {
	
	
employee e;
leavedetails l;

public leavemanager(employee e1,leavedetails l1) {
	this.e=e1;this.l=l1;
}
public void apply(int nol) throws qexception {
	int leave=l.getLeaves();
	if(leave<nol) {
		throw new qexception ("insufficient Balance");
	}
	else {
	int up=leave-nol;
	l.setLeaves(nol);}
}
public int viewleaves() {
	
	return l.getLeaves();
	}
public void update(int nol) {
	l.setLeaves(nol);
	
}

}
